package com.vishal.empmgmt.service;

import java.sql.SQLException;

public interface EmpService {
	public void registerEmp() throws SQLException;

	public void updateEmp() throws SQLException;

	public void deleteEmp() throws SQLException;

	public void getEmpById() throws SQLException;

	public void getEmpByName() throws SQLException;

	public void getEmpByDesignation() throws SQLException;

	public void getAllEmps() throws SQLException;

}
