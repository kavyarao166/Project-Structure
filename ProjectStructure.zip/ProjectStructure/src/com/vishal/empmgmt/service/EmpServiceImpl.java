package com.vishal.empmgmt.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.vishal.empmgmt.dao.EmployeeDao;
import com.vishal.empmgmt.dao.EmployeeDaoImpl;
import com.vishal.empmgmt.model.Employee;

public class EmpServiceImpl implements EmpService {
	EmployeeDao eDao = new EmployeeDaoImpl();
	@Override
	public void registerEmp() throws SQLException {


		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the name");
		String name = sc.next();
		System.out.println("Enter the designation");
		String designation = sc.next();

		Employee e = new Employee();
		e.setName(name);
		e.setDesignation(designation);

		eDao.registerEmp(e);
		System.out.println("One Record inserted successfully");
	}

	@Override
	public void updateEmp() throws SQLException {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteEmp() throws SQLException {
		// TODO Auto-generated method stub

	}

	@Override
	public void getEmpById() throws SQLException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Id which record you want");
		int id  =sc.nextInt();


		Employee e = eDao.getEmpById(id) ;
		System.out.println("ID:\tName:\tDesignation:");
		System.out.println(e.getId()+"\t"+e.getName()+"\t"+e.getDesignation());


	}

	@Override
	public void getEmpByName() throws SQLException {
		// TODO Auto-generated method stub

	}

	@Override
	public void getEmpByDesignation() throws SQLException {
		// TODO Auto-generated method stub

	}

	@Override
	public void getAllEmps() throws SQLException {

		List<Employee> emps = eDao.getAllEmps();



		System.out.println("ID:\tName:\tDesignation:");
		for (Employee e : emps) {

			System.out.println(e.getId() + "\t" + e.getName() + "\t" + e.getDesignation());
		}

	}

}
