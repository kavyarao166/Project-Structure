package com.vishal.empmgmt.test;

import java.sql.SQLException;
import java.util.Scanner;

import com.vishal.empmgmt.dao.EmployeeDao;
import com.vishal.empmgmt.dao.EmployeeDaoImpl;
import com.vishal.empmgmt.model.Employee;

public class GetRecord {

	public static void main(String[] args) throws SQLException {
		EmployeeDao eDao = new EmployeeDaoImpl();

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Id which record you want");
		int id  =sc.nextInt();


		Employee e = eDao.getEmpById(id) ;
		System.out.println("ID:\tName:\tDesignation:");
		System.out.println(e.getId()+"\t"+e.getName()+"\t"+e.getDesignation());


	}

}
