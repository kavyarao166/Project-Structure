package com.vishal.empmgmt.test;

import com.vishal.empmgmt.db.DBUtiltiy;

public class TestCon {

	public static void main(String[] args) {
		DBUtiltiy db = new DBUtiltiy();
		System.out.println(db.testCon());
	}

}
