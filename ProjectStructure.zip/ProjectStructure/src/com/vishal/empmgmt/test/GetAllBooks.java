package com.vishal.empmgmt.test;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.vishal.empmgmt.dao.EmployeeDao;
import com.vishal.empmgmt.dao.EmployeeDaoImpl;
import com.vishal.empmgmt.model.Employee;

public class GetAllBooks {

	public static void main(String[] args) throws SQLException {
		EmployeeDao eDao = new EmployeeDaoImpl();

		Scanner sc = new Scanner(System.in);

		List<Employee> emps = eDao.getAllEmps();



		System.out.println("ID:\tName:\tDesignation:");
		for (Employee e : emps) {

			System.out.println(e.getId() + "\t" + e.getName() + "\t" + e.getDesignation());
		}


	}

}
