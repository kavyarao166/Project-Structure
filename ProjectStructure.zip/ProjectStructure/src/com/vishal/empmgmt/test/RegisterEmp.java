package com.vishal.empmgmt.test;

import java.sql.SQLException;
import java.util.Scanner;

import com.vishal.empmgmt.dao.EmployeeDao;
import com.vishal.empmgmt.dao.EmployeeDaoImpl;
import com.vishal.empmgmt.model.Employee;

public class RegisterEmp {

	public static void main(String[] args) throws SQLException {
		EmployeeDao eDao = new EmployeeDaoImpl();

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the name");
		String name = sc.next();
		System.out.println("Enter the designation");
		String designation = sc.next();

		Employee e = new Employee();
		e.setName(name);
		e.setDesignation(designation);

		eDao.registerEmp(e);
		System.out.println("One Record inserted successfully");

	}

}
