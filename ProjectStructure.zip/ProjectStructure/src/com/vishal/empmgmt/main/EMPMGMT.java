package com.vishal.empmgmt.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.vishal.empmgmt.service.EmpService;
import com.vishal.empmgmt.service.EmpServiceImpl;

public class EMPMGMT {

	public static void main(String[] args) throws SQLException {
		EmpService service = new EmpServiceImpl();
		System.out.println("Welcome to EMP MGMT System");
		System.out.println("1. Press 1 to Register Employee");
		System.out.println("2. Press 2 to Updae Employee");
		System.out.println("3. Press 3 to Delete Employee");
		System.out.println("4. Press 4 to get Employee By ID");
		System.out.println("5. Press 5 to get Employee By Name");
		System.out.println("6. Press 6 to get Employee By Designation");
		System.out.println("7. Press 7 to get All Employees");
		System.out.println("8. Press 0 to exit the System");
		Scanner sc = new Scanner(System.in);

		boolean flag = true;
		while (flag) {
			System.out.println("Enter your choice");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				service.registerEmp();
				break;
			case 2:
				System.out.println("update");

				break;

			case 3:
				System.out.println("delete");

				break;
			case 4:
				service.getEmpById();

				break;
			case 5:
				System.out.println("get By name");

				break;
			case 6:
				System.out.println("get By des");

				break;
			case 7:
				service.getAllEmps();

				break;
			case 0:
				flag=false;
				System.out.println("Welcome Again!!!");
				System.exit(0);
				break;

			default:
				System.out.println("Enter valid choice");
				break;
			}
		}

	}

}
