package com.vishal.empmgmt.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.vishal.empmgmt.db.DBUtiltiy;
import com.vishal.empmgmt.model.Employee;

public class EmployeeDaoImpl implements EmployeeDao {
	DBUtiltiy db = new DBUtiltiy();
	PreparedStatement pst;
	ResultSet rs;

	@Override
	public int registerEmp(Employee emp) throws SQLException {
		String sql = "insert into employee(name,designation) values(?,?)";
		pst = db.createPST(sql);
		pst.setString(1, emp.getName());
		pst.setString(2, emp.getDesignation());
		return db.update(pst);
	}

	@Override
	public int updateEmp(Employee emp) throws SQLException {
		String sql = "update employee set name=?,desingation=? where id=?";
		pst = db.createPST(sql);
		pst.setString(1, emp.getName());
		pst.setString(2, emp.getDesignation());
		pst.setInt(3, emp.getId());
		return db.update(pst);
	}

	@Override
	public int deleteEmp(Employee emp) throws SQLException {
		String sql = "delete from employee where id=?";
		pst = db.createPST(sql);
		pst.setInt(1, emp.getId());
		return db.update(pst);
	}

	@Override
	public Employee getEmpById(int id) throws SQLException {
		// TODO Auto-generated method stub
		String sql = "select * from employee where id=?";
		pst = db.createPST(sql);
		pst.setInt(1, id);
		rs = db.query(pst);
		Employee emp = new Employee();
		if (rs.next()) {
			emp.setId(rs.getInt("id"));
			emp.setName(rs.getString("name"));
			emp.setDesignation(rs.getString("designation"));
		}
		return emp;
	}

	@Override
	public List<Employee> getEmpByName(String name) throws SQLException {
		String sql = "select * from employee where name=?";
		pst = db.createPST(sql);
		List<Employee> emps = new ArrayList<Employee>();
		pst.setString(1, name);
		rs = db.query(pst);
		while (rs.next()) {
			Employee emp = new Employee();
			emp.setId(rs.getInt("id"));
			emp.setName(rs.getString("name"));
			emp.setDesignation(rs.getString("designation"));
			emps.add(emp);
		}
		return emps;
	}

	@Override
	public List<Employee> getEmpByDesignation(String designation) throws SQLException {
		String sql = "select * from employee where designation=?";
		pst = db.createPST(sql);
		List<Employee> emps = new ArrayList<Employee>();
		pst.setString(1, designation);
		rs = db.query(pst);
		while (rs.next()) {
			Employee emp = new Employee();
			emp.setId(rs.getInt("id"));
			emp.setName(rs.getString("name"));
			emp.setDesignation(rs.getString("designation"));
			emps.add(emp);
		}
		return emps;
	}

	@Override
	public List<Employee> getAllEmps() throws SQLException {
		String sql = "select * from employee";
		pst = db.createPST(sql);
		List<Employee> emps = new ArrayList<Employee>();

		rs = db.query(pst);
		while (rs.next()) {
			Employee emp = new Employee();
			emp.setId(rs.getInt("id"));
			emp.setName(rs.getString("name"));
			emp.setDesignation(rs.getString("designation"));
			emps.add(emp);
		}
		return emps;
	}

}
