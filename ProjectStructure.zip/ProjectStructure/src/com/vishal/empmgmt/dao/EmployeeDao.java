package com.vishal.empmgmt.dao;

import java.sql.SQLException;
import java.util.List;

import com.vishal.empmgmt.model.Employee;

public interface EmployeeDao {

	public int registerEmp(Employee emp) throws SQLException;

	public int updateEmp(Employee emp) throws SQLException;

	public int deleteEmp(Employee emp) throws SQLException;

	public Employee getEmpById(int id) throws SQLException;

	public List<Employee> getEmpByName(String name) throws SQLException;

	public List<Employee> getEmpByDesignation(String designation) throws SQLException;

	public List<Employee> getAllEmps() throws SQLException;

}
